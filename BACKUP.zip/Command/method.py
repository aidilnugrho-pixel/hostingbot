import telebot, json
from telebot.types import ReplyKeyboardMarkup, KeyboardButton

try:
  with open('./config.json', 'r') as f:
    config = json.load(f)
except FileNotFoundError:
  config = {}
  
bot = telebot.TeleBot(config['TOKEN'])

class HandleMethod():
  def __init__(self, bot):
    self.bot = bot
    
  #Show Layer
  def show_layer(self, chat_id):
    layer = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    layer.add(KeyboardButton('Layer7-Basic'), KeyboardButton('Layer7-VIP'))
    layer.add(KeyboardButton('🛑 Stop'))
    layer.add(KeyboardButton('❌ Cancel'))
    self.bot.send_message(chat_id, 'Selected Layer attack : ', reply_markup=layer)
    
  def layer7_basic(self, chat_id):
    with open("./data/methods.json", "r") as file:
        methods_data = json.load(file)
        
    layer7_vip_methods = methods_data["methods"]["layer7"]["basic"]
    methods_keyboard = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    
    for method in layer7_vip_methods:
        methods_keyboard.add(KeyboardButton(method))
    methods_keyboard.add(KeyboardButton('❌ Cancel'))
    self.bot.send_message(chat_id, "Please select a Basic Layer7 attack method:", reply_markup=methods_keyboard)
    
  def layer7_vip(self, chat_id):
    with open("./data/methods.json", "r") as file:
        methods_data = json.load(file)
        
    layer7_vip_methods = methods_data["methods"]["layer7"]["vip"]
    methods_keyboard = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    
    for method in layer7_vip_methods:
        methods_keyboard.add(KeyboardButton(method))
    methods_keyboard.add(KeyboardButton('❌ Cancel'))
    self.bot.send_message(chat_id, "Please select a VIP Layer7 attack method:", reply_markup=methods_keyboard)
    
  #Layer4 Basic
  def layer4_basic(self, chat_id):
    methods = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    methods.add(KeyboardButton('OVH'),KeyboardButton('TCP'))
    methods.add(KeyboardButton('❌ Cancel'))
    self.bot.send_message(chat_id, 'Please select an attack method:', reply_markup=methods)
  
  #Layer4 VIP
  def layer4_vip(self, chat_id):
    methods = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    methods.add(KeyboardButton('UDP-POWER'),KeyboardButton('TCP-POWER'))
    methods.add(KeyboardButton('❌ Cancel'))
    self.bot.send_message(chat_id, 'Please select an attack method:', reply_markup=methods)